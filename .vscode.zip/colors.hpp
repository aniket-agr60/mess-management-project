#ifndef COLOR_HPP
#define COLOR_HPP

#define COLOR_RED "\x1b[1;31m"
#define COLOR_GREEN "\x1b[1;32m"
#define COLOR_YELLOW "\x1b[1;33m"
#define COLOR_DIM "\033[1;2m" // 21;m
#define COLOR_RESET "\033[0m"
#define ITALIC_MODE "\033[3m"
#define BOLD_MODE "\033[1m"
#define BG_WHITE "\033[1;47m"
#define BG_DIM "\033[1;48;5;98m"
#define BG_GREEN "\033[1;48;5;28m"
#define BG_YELLOW "\033[1;37;43m"
#define BG_BLACK "\033[1;48;5;234m"
#define BG_RED "\033[1;48;5;196m"
#define BG_BLUE "\033[1;48;5;21m"
#define STRIKE_MODE "\033[9m"
#define DIM "\033[1;48;5;236m"

#endif