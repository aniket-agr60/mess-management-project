#include "global.hpp"
#include "authority.hpp"
#include "student.hpp"
using namespace std;
enum IN
{
    IN_BACK = 8,
    IN_RET = 13
};
// Function that accepts the password
string takePasswdFromUser()
{
    char sp = '*';
    string passwd = "";
    char ch_ipt;
    while (true)
    {
        ch_ipt = getch();
        if (ch_ipt == IN::IN_RET)
        {
            cout << endl;
            return passwd;
        }
        else if (ch_ipt == IN::IN_BACK && passwd.length() != 0)
        {
            passwd.pop_back();
            cout << "\b \b";

            continue;
        }
        else if (ch_ipt == IN::IN_BACK && passwd.length() == 0)
        {
            continue;
        }

        passwd.push_back(ch_ipt);
        cout << BOLD_MODE << sp << COLOR_RESET;
    }
}

void transition(string chars)
{
    int n = chars.size();
    for (int i = 0; i < n; i++)
    {
        // usleep(115000);
        cout << chars.at(i);
    }
    return;
}
// overloading << operator for writing student info in file(student_record.csv)
ofstream &operator<<(ofstream &fout, Student &s)
{
    fout << s.getRoomNum() << "," << s.getName() << "," << s.getRollNum() << "," << s.getHostelInfo() << "," << ((s.isOff() == true) ? "off" : "on") << "," << s.getContact() << endl;
    return fout;
}

ofstream &operator<<(ofstream &fout, const vector<string> &v)
{
    int n = v.size();
    for (int i = 0; i < n - 1; i++)
    {
        fout << v.at(i) << ",";
    }
    fout << v.at(n - 1) << '\n';
    return fout;
}

ifstream &operator>>(ifstream &fin, Student *s) ////can be made more general function overloading
{
    string line = "";
    getline(fin, line);
    stringstream ss(line);
    vector<string> cols;
    string str;
    while (getline(ss, str, ',')) // yhi error aa aa rha tha ","
    {
        cols.push_back(str);
        str = "";
    }
    s->setDetails(cols);
    return fin; // for cascading
}

// general version of extraction operator that store strings in vector;
ifstream &operator>>(ifstream &fin, vector<string> &row) ////can be made more general function overloading
{
    string line = "";
    getline(fin, line);
    stringstream ss(line);
    string str;
    while (getline(ss, str, ',')) // yhi error aa aa rha tha ","
    {

        row.push_back(str);
        str = "";
    }
    return fin; // for cascading
}
